"""Linux account backup and local recovery tools inspired by ItsChasa's Discord-Backup."""

__version__ = "1.5.0"
